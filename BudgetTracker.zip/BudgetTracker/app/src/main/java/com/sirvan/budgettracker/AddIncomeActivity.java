public class AddIncomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_income);

        findViewById(R.id.btnSaveIncome).setOnClickListener(v ->
                Toast.makeText(this, "Gelir kaydedildi", Toast.LENGTH_SHORT).show()
        );
    }
}
