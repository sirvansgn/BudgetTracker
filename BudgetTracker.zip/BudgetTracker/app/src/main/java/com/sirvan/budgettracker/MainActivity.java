public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnIncome).setOnClickListener(v ->
                startActivity(new Intent(this, AddIncomeActivity.class)));

        findViewById(R.id.btnExpense).setOnClickListener(v ->
                startActivity(new Intent(this, AddExpenseActivity.class)));

        findViewById(R.id.btnList).setOnClickListener(v ->
                startActivity(new Intent(this, ListActivity.class)));

        findViewById(R.id.btnSummary).setOnClickListener(v ->
                startActivity(new Intent(this, SummaryActivity.class)));
    }
}
