public class AddExpenseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        findViewById(R.id.btnSaveExpense).setOnClickListener(v ->
                Toast.makeText(this, "Gider kaydedildi", Toast.LENGTH_SHORT).show()
        );
    }
}
